# Development Setup Guide

This guide provides comprehensive instructions for setting up a development environment for the SpecFirst framework. It covers all necessary tools, dependencies, and configuration steps.

## Purpose
The development setup guide ensures that developers can quickly and consistently set up their development environment for working with the SpecFirst framework. It provides step-by-step instructions for all required components.

## Prerequisites

### System Requirements
- **Operating System**: Linux (Ubuntu 20.04+), macOS (10.15+), or Windows 10+
- **Python**: Python 3.8 or higher
- **Memory**: Minimum 8GB RAM (16GB recommended)
- **Storage**: At least 10GB free space
- **Network**: Internet connection for package downloads

### Required Tools
- **Git**: Version control system
- **Python**: Programming language and runtime
- **Package Manager**: pip, conda, or mamba
- **Code Editor**: VS Code, PyCharm, or similar
- **Terminal**: Command line interface

## Installation Steps

### 1. Python Environment Setup

#### Using Conda/Mamba (Recommended)
```bash
# Install Miniconda or Mamba
# Download from: https://docs.conda.io/en/latest/miniconda.html

# Create a new environment
conda create -n specfirst python=3.11

# Activate the environment
conda activate specfirst

# Install required packages
conda install -c conda-forge mamba
mamba install -c conda-forge jupyter notebook
```

#### Using pip (Alternative)
```bash
# Create virtual environment
python -m venv specfirst-env

# Activate virtual environment
# On Linux/macOS:
source specfirst-env/bin/activate
# On Windows:
specfirst-env\Scripts\activate

# Upgrade pip
pip install --upgrade pip

# Install required packages
pip install jupyter notebook
```

### 2. Framework Installation

#### Clone the Repository
```bash
# Clone the framework repository
git clone https://github.com/your-org/specfirst-framework.git
cd specfirst-framework

# Install framework dependencies
pip install -r requirements.txt

# Install framework in development mode
pip install -e .
```

#### Install Development Dependencies
```bash
# Install development tools
pip install -r requirements-dev.txt

# Install testing frameworks
pip install pytest pytest-cov pytest-mock

# Install linting tools
pip install flake8 black isort mypy

# Install documentation tools
pip install sphinx sphinx-rtd-theme
```

### 3. IDE Configuration

#### VS Code Setup
```json
// .vscode/settings.json
{
    "python.defaultInterpreterPath": "./specfirst-env/bin/python",
    "python.linting.enabled": true,
    "python.linting.flake8Enabled": true,
    "python.formatting.provider": "black",
    "python.sortImports.args": ["--profile", "black"],
    "editor.formatOnSave": true,
    "editor.codeActionsOnSave": {
        "source.organizeImports": true
    }
}
```

#### PyCharm Setup
1. Open PyCharm
2. Create new project or open existing
3. Set Python interpreter to virtual environment
4. Install required packages
5. Configure code style settings

### 4. Configuration Setup

#### Environment Configuration
```bash
# Copy configuration template
cp config/config.json.template config/config.json

# Edit configuration file
nano config/config.json
```

#### Configuration Example
```json
{
  "development": {
    "debug": true,
    "log_level": "DEBUG",
    "database": "sqlite:///dev.db",
    "cache": "memory"
  },
  "testing": {
    "test_database": "sqlite:///test.db",
    "coverage_threshold": 80
  }
}
```

### 5. Database Setup

#### SQLite (Development)
```bash
# SQLite is included with Python
# No additional setup required for development
```

#### PostgreSQL (Production)
```bash
# Install PostgreSQL
# Ubuntu/Debian:
sudo apt-get install postgresql postgresql-contrib

# macOS:
brew install postgresql

# Windows:
# Download from https://www.postgresql.org/download/windows/

# Create database
createdb specfirst_dev
createdb specfirst_test
```

### 6. Validation Setup

#### Framework Validation
```bash
# Validate framework installation
python scripts/validate_project.py --root-dir .

# Check documentation structure
python scripts/check_docs.py --root-dir .

# Validate project structure
python scripts/check_structure.py --root-dir .
```

#### Test Environment
```bash
# Run tests to verify setup
pytest tests/

# Run with coverage
pytest --cov=src tests/

# Run linting
flake8 src/
black --check src/
isort --check-only src/
```

## Development Workflow Setup

### 1. Git Configuration
```bash
# Configure Git
git config user.name "Your Name"
git config user.email "your.email@example.com"

# Set up pre-commit hooks
pip install pre-commit
pre-commit install
```

### 2. Pre-commit Hooks
```yaml
# .pre-commit-config.yaml
repos:
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.4.0
    hooks:
      - id: trailing-whitespace
      - id: end-of-file-fixer
      - id: check-yaml
      - id: check-added-large-files

  - repo: https://github.com/psf/black
    rev: 23.3.0
    hooks:
      - id: black

  - repo: https://github.com/pycqa/isort
    rev: 5.12.0
    hooks:
      - id: isort

  - repo: https://github.com/pycqa/flake8
    rev: 6.0.0
    hooks:
      - id: flake8
```

### 3. Development Scripts
```bash
# Make scripts executable
chmod +x scripts/*.py

# Add scripts to PATH (optional)
export PATH=$PATH:$(pwd)/scripts
```

## Troubleshooting

### Common Issues

#### Python Environment Issues
```bash
# Check Python version
python --version

# Check pip version
pip --version

# Recreate virtual environment
rm -rf specfirst-env
python -m venv specfirst-env
source specfirst-env/bin/activate
pip install -r requirements.txt
```

#### Package Installation Issues
```bash
# Upgrade pip
pip install --upgrade pip

# Clear pip cache
pip cache purge

# Install with verbose output
pip install -v package-name

# Use alternative package manager
conda install package-name
```

#### Permission Issues
```bash
# Fix file permissions
chmod +x scripts/*.py

# Fix directory permissions
chmod 755 scripts/

# Use sudo if necessary (not recommended)
sudo pip install package-name
```

### Debugging Commands
```bash
# Check environment
python -c "import sys; print(sys.path)"

# Check installed packages
pip list

# Check framework installation
python -c "import specfirst; print(specfirst.__version__)"

# Validate setup
python scripts/validate_setup.py
```

## Best Practices

### Environment Management
- Use virtual environments for each project
- Keep requirements files updated
- Use version pinning for dependencies
- Document environment setup steps

### Configuration Management
- Use configuration templates
- Never commit sensitive data
- Use environment variables for secrets
- Validate configuration on startup

### Development Workflow
- Use pre-commit hooks
- Run tests before committing
- Follow coding standards
- Document changes

## References
- [Python Installation](https://www.python.org/downloads/)
- [Conda Documentation](https://docs.conda.io/)
- [VS Code Python](https://code.visualstudio.com/docs/languages/python)
- [PyCharm Documentation](https://www.jetbrains.com/pycharm/documentation/)
- [Framework Methodology](../framework/methodology/AGILE_SPECFIRST.md) 