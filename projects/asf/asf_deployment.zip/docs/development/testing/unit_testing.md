# Unit Testing Guide for SpecFirst Framework

This guide provides comprehensive instructions for implementing unit testing within the SpecFirst framework. It ensures that individual components are thoroughly tested in isolation, validating their behavior against specifications.

## Purpose
The unit testing guide establishes standards and practices for testing individual components, functions, and classes within the SpecFirst framework. It ensures comprehensive test coverage and validates that each component behaves correctly according to its specifications.

## Unit Testing Principles

### 1. Isolation
- Test each component in isolation
- Mock external dependencies
- Avoid test interdependencies
- Ensure test independence

### 2. Specification-Driven Testing
- Derive test cases from specifications
- Test all specified behaviors
- Validate against requirements
- Ensure specification compliance

### 3. Comprehensive Coverage
- Test all code paths
- Cover edge cases and error conditions
- Test boundary conditions
- Achieve minimum 80% code coverage

### 4. Maintainability
- Write readable and maintainable tests
- Use descriptive test names
- Follow consistent patterns
- Keep tests simple and focused

## Test Structure

### Test Organization
```
tests/
├── unit/                    # Unit tests
│   ├── test_models.py       # Model tests
│   ├── test_services.py     # Service tests
│   ├── test_utils.py        # Utility function tests
│   └── test_validators.py   # Validator tests
├── fixtures/                # Test fixtures
│   ├── conftest.py          # Pytest configuration
│   └── test_data.py         # Test data
└── utils/                   # Testing utilities
    ├── test_helpers.py      # Helper functions
    └── assertions.py        # Custom assertions
```

### Test File Structure
```python
# test_example.py
# Copyright (c) 2025, Jaime Moraga (jmoraga@mines.edu)

"""
Unit tests for example module.

This module contains unit tests for the example functionality,
validating behavior against specifications.
"""

import pytest
from unittest.mock import Mock, patch
from typing import Dict, Any

from src.example import ExampleClass, example_function


class TestExampleClass:
    """Test cases for ExampleClass."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.example = ExampleClass()
    
    def test_initialization(self):
        """Test class initialization."""
        assert self.example is not None
        assert hasattr(self.example, 'attribute')
    
    def test_method_with_valid_input(self):
        """Test method with valid input."""
        result = self.example.method("valid_input")
        assert result == "expected_output"
    
    def test_method_with_invalid_input(self):
        """Test method with invalid input."""
        with pytest.raises(ValueError):
            self.example.method("invalid_input")


class TestExampleFunction:
    """Test cases for example_function."""
    
    def test_function_success(self):
        """Test function with successful execution."""
        result = example_function("test_data")
        assert result["status"] == "success"
        assert "data" in result
    
    def test_function_failure(self):
        """Test function with failure condition."""
        with pytest.raises(Exception):
            example_function(None)
    
    @patch('src.example.external_service')
    def test_function_with_mock(self, mock_service):
        """Test function with mocked external service."""
        mock_service.return_value = "mocked_result"
        result = example_function("test_data")
        assert result == "mocked_result"
        mock_service.assert_called_once_with("test_data")
```

## Test Patterns

### Arrange-Act-Assert Pattern
```python
def test_user_creation():
    """Test user creation functionality."""
    # Arrange - Set up test data
    user_data = {
        "username": "testuser",
        "email": "test@example.com",
        "password": "securepass123"
    }
    expected_user_id = "user_123"
    
    # Act - Execute the function
    result = create_user(user_data)
    
    # Assert - Verify the result
    assert result["user_id"] == expected_user_id
    assert result["username"] == user_data["username"]
    assert result["email"] == user_data["email"]
```

### Given-When-Then Pattern
```python
def test_user_authentication():
    """Test user authentication."""
    # Given - A valid user exists
    user = create_test_user()
    
    # When - User attempts to authenticate
    result = authenticate_user(user.username, "correct_password")
    
    # Then - Authentication should succeed
    assert result["authenticated"] is True
    assert result["user_id"] == user.id
```

### Test Fixtures
```python
@pytest.fixture
def sample_user_data():
    """Provide sample user data for testing."""
    return {
        "username": "testuser",
        "email": "test@example.com",
        "password": "securepass123",
        "first_name": "Test",
        "last_name": "User"
    }


@pytest.fixture
def mock_database():
    """Provide mock database for testing."""
    with patch('src.database.get_connection') as mock:
        mock.return_value = Mock()
        yield mock


@pytest.fixture
def test_user(sample_user_data, mock_database):
    """Provide test user for testing."""
    return create_user(sample_user_data)
```

## Mocking and Stubbing

### Mocking External Dependencies
```python
@patch('src.services.email_service.send_email')
def test_user_registration_sends_email(mock_send_email):
    """Test that user registration sends confirmation email."""
    # Arrange
    user_data = {"email": "test@example.com"}
    
    # Act
    register_user(user_data)
    
    # Assert
    mock_send_email.assert_called_once_with(
        to="test@example.com",
        subject="Welcome",
        template="welcome_email"
    )


@patch('src.services.payment_service.process_payment')
def test_payment_processing(mock_process_payment):
    """Test payment processing with mock."""
    # Arrange
    mock_process_payment.return_value = {"status": "success", "transaction_id": "txn_123"}
    payment_data = {"amount": 100, "currency": "USD"}
    
    # Act
    result = process_payment(payment_data)
    
    # Assert
    assert result["status"] == "success"
    assert result["transaction_id"] == "txn_123"
    mock_process_payment.assert_called_once_with(payment_data)
```

### Stubbing Internal Methods
```python
class TestUserService:
    """Test cases for UserService."""
    
    def test_get_user_by_id(self):
        """Test getting user by ID."""
        # Arrange
        service = UserService()
        user_id = "user_123"
        expected_user = {"id": user_id, "name": "Test User"}
        
        with patch.object(service, '_fetch_from_database') as mock_fetch:
            mock_fetch.return_value = expected_user
            
            # Act
            result = service.get_user_by_id(user_id)
            
            # Assert
            assert result == expected_user
            mock_fetch.assert_called_once_with(user_id)
```

## Test Data Management

### Test Data Factories
```python
class UserFactory:
    """Factory for creating test user data."""
    
    @staticmethod
    def create_user_data(**kwargs):
        """Create user data with defaults."""
        default_data = {
            "username": "testuser",
            "email": "test@example.com",
            "password": "securepass123",
            "first_name": "Test",
            "last_name": "User"
        }
        default_data.update(kwargs)
        return default_data
    
    @staticmethod
    def create_invalid_user_data():
        """Create invalid user data for testing."""
        return {
            "username": "",  # Invalid: empty username
            "email": "invalid-email",  # Invalid: malformed email
            "password": "123"  # Invalid: too short
        }


# Usage in tests
def test_user_creation_with_factory():
    """Test user creation using factory."""
    user_data = UserFactory.create_user_data(username="customuser")
    result = create_user(user_data)
    assert result["username"] == "customuser"


def test_user_creation_with_invalid_data():
    """Test user creation with invalid data."""
    invalid_data = UserFactory.create_invalid_user_data()
    with pytest.raises(ValidationError):
        create_user(invalid_data)
```

### Test Data Cleanup
```python
@pytest.fixture(autouse=True)
def cleanup_test_data():
    """Clean up test data after each test."""
    yield
    # Cleanup code here
    cleanup_database()
    cleanup_files()


def cleanup_database():
    """Clean up test database."""
    # Database cleanup logic
    pass


def cleanup_files():
    """Clean up test files."""
    # File cleanup logic
    pass
```

## Assertion Patterns

### Custom Assertions
```python
def assert_user_data(user_data: Dict[str, Any], expected_data: Dict[str, Any]):
    """Assert that user data matches expected values."""
    for key, value in expected_data.items():
        assert user_data[key] == value, f"User data mismatch for {key}"


def assert_api_response(response: Dict[str, Any]):
    """Assert that API response has correct structure."""
    assert "status" in response, "Response missing 'status' field"
    assert "data" in response, "Response missing 'data' field"
    assert response["status"] in ["success", "error"], "Invalid status value"


def assert_error_response(response: Dict[str, Any], expected_error: str):
    """Assert that error response is correct."""
    assert response["status"] == "error"
    assert "error" in response
    assert expected_error in response["error"]


# Usage in tests
def test_user_creation_success():
    """Test successful user creation."""
    user_data = UserFactory.create_user_data()
    result = create_user(user_data)
    
    assert_api_response(result)
    assert result["status"] == "success"
    assert_user_data(result["data"], user_data)


def test_user_creation_failure():
    """Test user creation failure."""
    invalid_data = UserFactory.create_invalid_user_data()
    result = create_user(invalid_data)
    
    assert_error_response(result, "Validation failed")
```

## Test Configuration

### Pytest Configuration
```ini
# pytest.ini
[tool:pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts = 
    --verbose
    --tb=short
    --strict-markers
    --disable-warnings
    --cov=src
    --cov-report=html
    --cov-report=term-missing
markers =
    unit: Unit tests
    slow: Slow running tests
    integration: Integration tests
    e2e: End-to-end tests
```

### Test Environment Setup
```python
# conftest.py
import pytest
import os
import sys
from pathlib import Path

# Add src to path
src_path = Path(__file__).parent.parent / "src"
sys.path.insert(0, str(src_path))

# Test configuration
@pytest.fixture(scope="session")
def test_config():
    """Provide test configuration."""
    return {
        "database": "sqlite:///test.db",
        "debug": True,
        "log_level": "DEBUG"
    }


@pytest.fixture(autouse=True)
def setup_test_environment(test_config):
    """Set up test environment."""
    # Set environment variables
    os.environ["TESTING"] = "true"
    os.environ["DATABASE_URL"] = test_config["database"]
    
    yield
    
    # Cleanup
    os.environ.pop("TESTING", None)
    os.environ.pop("DATABASE_URL", None)
```

## Best Practices

### Test Naming
```python
# Good test names
def test_user_creation_with_valid_data():
    """Test user creation with valid input data."""

def test_user_creation_fails_with_invalid_email():
    """Test that user creation fails with invalid email."""

def test_user_creation_sends_welcome_email():
    """Test that user creation sends welcome email."""

# Bad test names
def test_user():  # Too vague
    pass

def test_1():  # Not descriptive
    pass

def test_user_creation_works():  # Not specific
    pass
```

### Test Organization
```python
class TestUserService:
    """Test cases for UserService."""
    
    # Group related tests together
    class TestUserCreation:
        """Test user creation functionality."""
        
        def test_creates_user_with_valid_data(self):
            """Test creating user with valid data."""
            pass
        
        def test_fails_with_invalid_data(self):
            """Test that creation fails with invalid data."""
            pass
    
    class TestUserRetrieval:
        """Test user retrieval functionality."""
        
        def test_retrieves_user_by_id(self):
            """Test retrieving user by ID."""
            pass
        
        def test_returns_none_for_nonexistent_user(self):
            """Test that retrieval returns None for nonexistent user."""
            pass
```

### Test Independence
```python
class TestUserService:
    """Test cases for UserService."""
    
    def setup_method(self):
        """Set up fresh test environment for each test."""
        self.service = UserService()
        self.cleanup_database()
    
    def teardown_method(self):
        """Clean up after each test."""
        self.cleanup_database()
    
    def cleanup_database(self):
        """Clean up test database."""
        # Database cleanup logic
        pass
```

## References
- [Testing Guide](README.md)
- [Integration Testing](integration_testing.md)
- [End-to-End Testing](e2e_testing.md)
- [Testing Workflow](../workflow/testing_workflow.md)
- [Framework Methodology](../../framework/methodology/AGILE_SPECFIRST.md) 