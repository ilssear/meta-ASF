# Testing Guide for SpecFirst Framework

This guide covers testing practices, strategies, and tools for the SpecFirst framework. It ensures comprehensive testing coverage and quality assurance throughout the development process.

## Purpose
The testing guide establishes standards and practices for testing within the SpecFirst framework. It ensures that all components are thoroughly tested and validated against specifications, maintaining high quality and reliability.

## Testing Philosophy

### Specification-Driven Testing
- All tests should be derived from specifications
- Tests validate implementation against specifications
- Test cases should cover all specification requirements
- Testing should be automated and repeatable

### Quality Assurance
- **Completeness**: All functionality must be tested
- **Accuracy**: Tests must validate correct behavior
- **Reliability**: Tests must be consistent and repeatable
- **Maintainability**: Tests must be easy to update and maintain

## Testing Types

### 1. Unit Testing
- **Purpose**: Test individual components in isolation
- **Scope**: Functions, classes, and modules
- **Tools**: pytest, unittest, nose
- **Coverage**: 80% minimum code coverage

### 2. Integration Testing
- **Purpose**: Test component interactions
- **Scope**: API endpoints, database operations, external services
- **Tools**: pytest, requests, testcontainers
- **Coverage**: All integration points

### 3. End-to-End Testing
- **Purpose**: Test complete user workflows
- **Scope**: Full application functionality
- **Tools**: Selenium, Playwright, Cypress
- **Coverage**: Critical user journeys

### 4. Performance Testing
- **Purpose**: Validate performance requirements
- **Scope**: Response times, throughput, resource usage
- **Tools**: locust, pytest-benchmark, artillery
- **Coverage**: Performance specifications

### 5. Security Testing
- **Purpose**: Validate security requirements
- **Scope**: Authentication, authorization, data protection
- **Tools**: bandit, safety, OWASP ZAP
- **Coverage**: Security specifications

## Testing Structure

### Test Organization
```
tests/
├── unit/                    # Unit tests
│   ├── test_models.py
│   ├── test_services.py
│   └── test_utils.py
├── integration/             # Integration tests
│   ├── test_api.py
│   ├── test_database.py
│   └── test_external.py
├── e2e/                     # End-to-end tests
│   ├── test_user_flows.py
│   └── test_critical_paths.py
├── performance/             # Performance tests
│   ├── test_load.py
│   └── test_stress.py
├── security/                # Security tests
│   ├── test_auth.py
│   └── test_vulnerabilities.py
├── fixtures/                # Test fixtures
│   ├── conftest.py
│   └── test_data.py
└── utils/                   # Testing utilities
    ├── test_helpers.py
    └── assertions.py
```

### Test Configuration
```python
# pytest.ini
[tool:pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts = 
    --verbose
    --tb=short
    --strict-markers
    --disable-warnings
    --cov=src
    --cov-report=html
    --cov-report=term-missing
markers =
    unit: Unit tests
    integration: Integration tests
    e2e: End-to-end tests
    performance: Performance tests
    security: Security tests
    slow: Slow running tests
```

## Testing Workflow

### 1. Test Planning
```markdown
## Test Plan Template

### Test Objectives
- [ ] Validate specification compliance
- [ ] Ensure functionality works correctly
- [ ] Verify performance requirements
- [ ] Confirm security requirements

### Test Scope
- [ ] Unit tests for all components
- [ ] Integration tests for APIs
- [ ] E2E tests for user workflows
- [ ] Performance tests for critical paths
- [ ] Security tests for vulnerabilities

### Test Data
- [ ] Test fixtures prepared
- [ ] Mock data available
- [ ] Database test data ready
- [ ] External service mocks configured
```

### 2. Test Development
1. **Review Specifications**: Understand what needs to be tested
2. **Design Test Cases**: Create comprehensive test scenarios
3. **Write Tests**: Implement test code following standards
4. **Create Fixtures**: Prepare test data and setup
5. **Validate Tests**: Ensure tests are correct and complete

### 3. Test Execution
```bash
# Run all tests
pytest

# Run specific test types
pytest -m unit
pytest -m integration
pytest -m e2e

# Run with coverage
pytest --cov=src --cov-report=html

# Run performance tests
pytest tests/performance/ -v

# Run security tests
pytest tests/security/ -v
```

### 4. Test Validation
- **Test Results**: All tests must pass
- **Coverage**: Meet minimum coverage requirements
- **Performance**: Meet performance benchmarks
- **Security**: Pass all security checks

## Testing Tools

### Core Testing Framework
```python
# pytest configuration
import pytest
from typing import Dict, Any

@pytest.fixture
def test_config() -> Dict[str, Any]:
    """Provide test configuration."""
    return {
        "database": "sqlite:///test.db",
        "debug": True,
        "log_level": "DEBUG"
    }

@pytest.fixture
def test_client():
    """Provide test client for API testing."""
    from app import create_app
    app = create_app(test_config())
    with app.test_client() as client:
        yield client
```

### Mocking and Stubbing
```python
# Mock external services
import pytest
from unittest.mock import Mock, patch

@pytest.fixture
def mock_external_service():
    """Mock external service for testing."""
    with patch('app.services.external_service') as mock:
        mock.return_value = Mock()
        yield mock

def test_with_mock(mock_external_service):
    """Test using mocked external service."""
    mock_external_service.get_data.return_value = {"test": "data"}
    # Test implementation
```

### Database Testing
```python
# Database test fixtures
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

@pytest.fixture
def test_db():
    """Provide test database."""
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    yield session
    session.close()
```

## Test Standards

### Naming Conventions
```python
# Test file naming
test_module_name.py          # test_models.py
test_class_name.py           # test_user_service.py

# Test function naming
def test_function_name():     # test_create_user()
def test_function_with_condition():  # test_create_user_with_invalid_data()

# Test class naming
class TestClassName:          # TestUserService
class TestClassWithCondition: # TestUserServiceWithInvalidData
```

### Test Structure
```python
# Standard test structure
def test_function_name():
    """Test description."""
    # Arrange - Set up test data
    input_data = {"key": "value"}
    expected_result = "expected"
    
    # Act - Execute the function
    result = function_under_test(input_data)
    
    # Assert - Verify the result
    assert result == expected_result
```

### Assertion Standards
```python
# Use descriptive assertions
assert result.status_code == 200, f"Expected 200, got {result.status_code}"
assert len(users) == 3, f"Expected 3 users, got {len(users)}"
assert user.name == "John", f"Expected name 'John', got '{user.name}'"

# Use pytest assertions for better error messages
import pytest
pytest.approx(expected_value, rel=1e-3)  # For floating point comparisons
```

## Quality Assurance

### Test Coverage
```bash
# Generate coverage report
pytest --cov=src --cov-report=html --cov-report=term-missing

# Coverage requirements
# - Minimum 80% line coverage
# - Minimum 90% branch coverage for critical paths
# - 100% coverage for security-critical code
```

### Test Quality Checklist
```markdown
## Test Quality Checklist

### Test Design
- [ ] Tests are derived from specifications
- [ ] Test cases cover all requirements
- [ ] Edge cases are tested
- [ ] Error conditions are tested

### Test Implementation
- [ ] Tests are readable and maintainable
- [ ] Tests are independent and isolated
- [ ] Tests use appropriate fixtures
- [ ] Tests have clear assertions

### Test Execution
- [ ] All tests pass consistently
- [ ] Tests run in reasonable time
- [ ] Tests provide useful error messages
- [ ] Tests are properly categorized
```

## Continuous Integration

### CI/CD Integration
```yaml
# .github/workflows/test.yml
name: Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: 3.11
      - name: Install dependencies
        run: |
          pip install -r requirements.txt
          pip install -r requirements-dev.txt
      - name: Run tests
        run: |
          pytest --cov=src --cov-report=xml
      - name: Upload coverage
        uses: codecov/codecov-action@v1
```

### Test Automation
- **Pre-commit**: Run tests before commits
- **CI Pipeline**: Run tests on every push
- **Nightly**: Run full test suite nightly
- **Release**: Run tests before releases

## Best Practices

### Test Development
- Write tests before or alongside code (TDD)
- Keep tests simple and focused
- Use descriptive test names
- Avoid test interdependencies
- Use appropriate test data

### Test Maintenance
- Update tests when specifications change
- Refactor tests to improve maintainability
- Remove obsolete tests
- Monitor test performance
- Regular test reviews

### Test Documentation
- Document test purpose and scope
- Explain complex test scenarios
- Document test data requirements
- Maintain test runbooks
- Update test documentation

## References
- [Unit Testing Guide](unit_testing.md)
- [Integration Testing Guide](integration_testing.md)
- [End-to-End Testing Guide](e2e_testing.md)
- [Testing Workflow](../workflow/testing_workflow.md)
- [Framework Methodology](../../framework/methodology/AGILE_SPECFIRST.md) 