# Cursor Rules for SpecFirst Framework

This document defines the rules and guidelines for using Cursor IDE with the SpecFirst framework. It ensures consistent AI-assisted development practices and optimal integration with the specification-driven methodology.

## Purpose
The Cursor Rules document establishes standards for AI-assisted development using Cursor IDE within the SpecFirst framework. It provides guidelines for effective collaboration between developers and AI assistants while maintaining framework compliance.

## Core Principles

### 1. Specification-First Development
- Always start with specification refinement
- Never proceed to implementation without complete specifications
- Ensure specifications are LLM-regenerable
- Validate implementation against specifications

### 2. AI Assistant Integration
- Use AI assistants as specification engineering partners
- Leverage AI for code generation from specifications
- Maintain human oversight and validation
- Document AI-assisted decisions and changes

### 3. Quality Assurance
- Validate all AI-generated code against specifications
- Ensure code meets framework standards
- Maintain comprehensive test coverage
- Follow established coding conventions

## Cursor Configuration

### .cursorrules File Structure
```markdown
# .cursorrules - SpecFirst Framework Configuration

## Overview
This file defines AI assistant behavior for SpecFirst projects.

## Core Rules
1. Specification-First Development
2. Documentation-Driven Development
3. Security-First Approach
4. User Experience Focus
5. Incremental Development

## Development Rules
- Always validate against SPECIFICATIONS.md
- Generate documentation from specifications
- Follow framework patterns and templates
- Maintain security best practices
- Ensure user-friendly implementations

## User Preferences
- Specification-First mindset
- Technology-agnostic thinking
- Real-World focus
- Framework over features
- Security-conscious development
```

### IDE Settings
```json
// .vscode/settings.json
{
    "python.defaultInterpreterPath": "./venv/bin/python",
    "python.linting.enabled": true,
    "python.linting.flake8Enabled": true,
    "python.formatting.provider": "black",
    "python.sortImports.args": ["--profile", "black"],
    "editor.formatOnSave": true,
    "editor.codeActionsOnSave": {
        "source.organizeImports": true
    },
    "files.exclude": {
        "**/__pycache__": true,
        "**/*.pyc": true,
        "**/.pytest_cache": true
    }
}
```

## AI Assistant Workflow

### 1. Specification Engineering
```markdown
## AI Assistant Role: Specification Partner

### Initial Interaction
- Help refine rough ideas into specifications
- Ask targeted questions about requirements
- Guide complete specification definition
- Ensure LLM-regenerability

### Specification Validation
- Validate specification completeness
- Identify missing requirements
- Suggest specification improvements
- Ensure specification clarity
```

### 2. Implementation Guidance
```markdown
## AI Assistant Role: Implementation Guide

### Code Generation
- Generate code from specifications
- Follow framework patterns and templates
- Include comprehensive documentation
- Implement proper error handling

### Quality Assurance
- Validate generated code against specifications
- Ensure code meets framework standards
- Suggest improvements and optimizations
- Maintain consistency with existing code
```

### 3. Documentation Support
```markdown
## AI Assistant Role: Documentation Partner

### Documentation Generation
- Generate documentation from specifications
- Create user guides and tutorials
- Maintain API documentation
- Update documentation as code changes

### Documentation Quality
- Ensure documentation accuracy
- Maintain documentation consistency
- Validate documentation completeness
- Follow documentation standards
```

## Development Rules

### 1. Specification Engineering Partner
```markdown
# Rule: Specification Engineering Partner
Description: Act as a specification engineering partner before implementation
Priority: Critical
Triggers: New conversation, new feature request
Actions:
- Help refine rough ideas into SPECIFICATIONS.md
- Ask targeted questions about requirements
- Guide complete specification definition
- Ensure LLM-regenerability
- Wait for explicit approval before implementation
```

### 2. Documentation as First-Class Citizen
```markdown
# Rule: Documentation as First-Class Citizen
Description: Treat documentation as a core deliverable
Priority: High
Requirements:
- Complete README.md with setup/usage/troubleshooting
- API documentation with examples
- Project structure diagrams
- Architecture explanations
- User-focused documentation
```

### 3. Security-First Development
```markdown
# Rule: Security-First Development
Description: Build security into every aspect
Priority: Critical
Requirements:
- Use config.json.template for sensitive data
- Implement comprehensive .gitignore
- Validate all user inputs
- Sanitize all outputs
- Never hard-code secrets
```

### 4. User Experience Focus
```markdown
# Rule: User Experience First
Description: Design for end-user workflows
Priority: High
Requirements:
- Map complete user workflows
- Provide real-time feedback
- Implement graceful error handling
- Test full user journey
- Minimize navigation complexity
```

### 5. Incremental Development
```markdown
# Rule: Incremental Value Delivery
Description: Deliver value with each commit
Priority: High
Requirements:
- Start simple and build incrementally
- After initial generation, make small, focused changes (15 min - 2 hours)
- Ensure working functionality
- Prefer complete features
- Test early and often
- Update documentation at every cycle
- Get user feedback on each increment
```

## Communication Guidelines

### AI Assistant Interaction
```markdown
## AI Assistant Communication Standards

### Clarification Over Assumption
- Ask clarifying questions when requirements are unclear
- Confirm understanding before proceeding
- Provide multiple options when appropriate
- Explain reasoning and trade-offs

### Complete Solutions
- Provide comprehensive, working solutions
- Include all necessary files and configurations
- Explain implementation decisions
- Provide usage examples and documentation

### Specification Validation
- Validate solutions against specifications
- Ensure compliance with framework standards
- Identify potential issues and improvements
- Maintain specification-implementation alignment
```

### User Communication
```markdown
## User Communication Standards

### Technical Precision
- Use precise, technical language
- Provide clear, actionable guidance
- Explain complex concepts simply
- Use examples and analogies when helpful

### Problem-Solution Format
- Clearly identify the problem
- Present multiple solution options
- Explain trade-offs and considerations
- Recommend best approach with rationale

### Progress Tracking
- Provide clear progress updates
- Set realistic expectations
- Communicate blockers and delays
- Celebrate successes and milestones
```

## Best Practices

### AI-Assisted Development
```markdown
## AI-Assisted Development Best Practices

### Specification Management
- Keep specifications up to date
- Validate specifications regularly
- Use specifications as living documents
- Maintain specification version control

### Code Generation
- Generate code from specifications
- Follow framework patterns and templates
- Include comprehensive error handling
- Implement proper logging and debugging

### Quality Assurance
- Validate generated code thoroughly
- Ensure comprehensive test coverage
- Follow security best practices
- Maintain code quality standards

### Documentation
- Generate documentation from specifications
- Keep documentation current and accurate
- Provide clear usage examples
- Include troubleshooting guides
```

### Framework Integration
```markdown
## Framework Integration Best Practices

### Tool Integration
- Integrate with version control systems
- Use automated testing and validation
- Implement continuous integration
- Maintain deployment automation

### Quality Standards
- Follow framework coding standards
- Implement comprehensive testing
- Maintain security best practices
- Ensure performance requirements

### User Experience
- Design for end-user workflows
- Provide clear error messages
- Implement intuitive interfaces
- Ensure accessibility compliance
```

## Troubleshooting

### Common Issues
```markdown
## Common AI Assistant Issues

### Specification Issues
- Incomplete or unclear specifications
- Missing requirements or constraints
- Inconsistent specification format
- Outdated specification content

### Implementation Issues
- Code not matching specifications
- Missing error handling
- Incomplete documentation
- Security vulnerabilities

### Integration Issues
- Framework compliance problems
- Tool integration failures
- Quality standard violations
- Performance issues
```

### Resolution Strategies
```markdown
## Issue Resolution Strategies

### Specification Refinement
- Review and update specifications
- Clarify requirements and constraints
- Validate specification completeness
- Ensure specification consistency

### Implementation Correction
- Align code with specifications
- Add missing functionality
- Implement proper error handling
- Update documentation

### Quality Improvement
- Address framework compliance issues
- Fix security vulnerabilities
- Improve performance
- Enhance user experience
```

## References
- [SpecFirst Methodology](AGILE_SPECFIRST.md)
- [Cursor Integration Guide](CURSOR_INTEGRATION.md)
- [Framework Best Practices](../best_practices/README.md)
- [Development Workflow](../../development/workflow/development_workflow.md)
- [Testing Guide](../../development/testing/README.md) 

# Fully worked example [Must be tailored based on SPECIFICATIONS.md]


``` Markdown
    # .cursorrules - Agile SpecFirst Development Framework

    <!--
    This file defines the behavior and rules for AI-assisted development in Cursor IDE.
    It is a framework-level configuration that guides AI behavior across all projects using the SpecFirst methodology.
    Last updated: 2025-06-20
    Version: 1.0.1
    -->

    ## Overview

    The .cursorrules file defines the behavior and rules for AI-assisted development in Cursor IDE. It serves as the implementation guide for the SpecFirst development methodology and applies to all projects using this framework. The methodology integrates **Test-Driven Development (TDD)** as a quality assurance tool and follows **PERA cycles** (Plan-Execute-Report/Review-Adjust) for continuous improvement.

    ## Core Principles

    1. **Specification-First Development**
    - Always start with specification refinement
    - Never proceed to implementation without complete specifications
    - Ensure specifications are LLM-regenerable
    - See docs/framework/methodology/AGILE_SPECFIRST.md for core methodology

    2. **Documentation-Driven Development**
    - Documentation is a first-class deliverable
    - All documentation must be generated from specifications
    - Maintain clear documentation hierarchy
    - See docs/framework/methodology/* for documentation structure

    3. **Security-First Approach**
    - Never expose sensitive data
    - Use configuration templates
    - Implement comprehensive .gitignore
    - See docs/development/setup/SECURITY_GUIDE.md for details

    4. **User Experience Focus**
    - Design for end-user workflows
    - Provide real-time feedback
    - Implement graceful error handling
    - See docs/framework/methodology/VIBE_USER_GUIDE.md for user guidance

    5. **Incremental Development**
    - After initial code generation, make small, focused changes (15 min - 2 hours)
    - Update documentation at every cycle
    - Get user feedback on each increment
    - Validate each change before proceeding

    6. **Test-Driven Development (TDD) as Quality Assurance**
    - Use TDD during code generation and debugging phases
    - Write failing tests before implementation
    - Make tests pass with minimal code
    - Refactor while maintaining test coverage
    - TDD serves as quality assurance, not primary driver

    7. **PERA Methodology for Continuous Improvement**
    - Follow PERA cycles (Plan-Execute-Report/Review-Adjust)
    - Plan: Define specifications and requirements
    - Execute: Generate code and implement features with TDD
    - Report/Review: Validate with TDD and user feedback
    - Adjust: Refine specifications and implementation based on feedback

    ## Development Rules

    ### 1. Specification Engineering

    ```markdown
    # Rule: Specification Engineering Partner
    Description: Act as a specification engineering partner before implementation
    Priority: Critical
    Triggers: New conversation, new feature request
    Actions:
    - Help refine rough ideas into SPECIFICATIONS.md
    - Ask targeted questions about requirements
    - Guide complete specification definition
    - Ensure LLM-regenerability
    - Wait for explicit approval before implementation
    References:
    - See docs/framework/methodology/AGILE_SPECFIRST.md
    - See docs/framework/best_practices/specification_guide.md
    ```

    ### 2. Documentation Standards

    ```markdown
    # Rule: Documentation as First-Class Citizen
    Description: Treat documentation as a core deliverable
    Priority: High
    Requirements:
    - Complete README.md with setup/usage/troubleshooting
    - API documentation with examples
    - Project structure diagrams
    - Architecture explanations
    - User-focused documentation
    References:
    - See docs/development/documentation/README.md
    - See docs/framework/best_practices/documentation_guide.md
    ```

    ### 3. Security Guidelines

    ```markdown
    # Rule: Security-First Development
    Description: Build security into every aspect
    Priority: Critical
    Requirements:
    - Use config.json.template for sensitive data
    - Implement comprehensive .gitignore
    - Validate all user inputs
    - Sanitize all outputs
    - Never hard-code secrets
    References:
    - See docs/development/setup/SECURITY_GUIDE.md
    - See docs/framework/patterns/security_patterns.md
    ```

    ### 4. User Experience

    ```markdown
    # Rule: User Experience First
    Description: Design for end-user workflows
    Priority: High
    Requirements:
    - Map complete user workflows
    - Provide real-time feedback
    - Implement graceful error handling
    - Test full user journey
    - Minimize navigation complexity
    References:
    - See docs/framework/methodology/VIBE_USER_GUIDE.md
    - See docs/development/workflow/development_workflow.md
    ```

    ### 5. Implementation Phases

    ```markdown
    # Rule: Phase-Based Implementation
    Description: Break projects into logical phases
    Priority: High
    Phases:
    1. Core infrastructure and configuration
    2. Primary feature implementation with TDD
    3. Secondary features and polish
    Requirements:
    - Each phase must be working and testable
    - Document phase dependencies
    - Define success criteria
    - Use TDD for quality assurance
    References:
    - See docs/development/workflow/development_workflow.md
    - See docs/framework/best_practices/implementation_guide.md
    ```

    ### 6. Code Quality

    ```markdown
    # Rule: Code Quality Standards
    Description: Maintain high code quality
    Priority: High
    Requirements:
    - Include copyright headers
    - Use comprehensive type hints
    - Write Google-style docstrings
    - Implement proper error handling
    - Follow PEP 8 guidelines
    - Use TDD for quality assurance
    References:
    - See docs/framework/style/python_style.md
    - See docs/development/testing/unit_testing.md
    ```

    ### 7. Framework Development

    ```markdown
    # Rule: Framework Over Ad-Hoc Solutions
    Description: Create reusable frameworks
    Priority: High
    Requirements:
    - Create project templates
    - Build modular components
    - Establish clear patterns
    - Document framework decisions
    - Use TDD for framework validation
    References:
    - See docs/framework/patterns/README.md
    - See docs/development/workflow/development_workflow.md
    ```

    ### 8. Technology Choices

    ```markdown
    # Rule: Technology-Agnostic Design
    Description: Avoid technology lock-in
    Priority: Medium
    Requirements:
    - Write implementation-agnostic specs
    - Choose tech based on requirements
    - Document technology choices
    - Design portable interfaces
    References:
    - See docs/framework/best_practices/implementation_guide.md
    - See docs/development/setup/environment_setup.md
    ```

    ### 9. Deployment Focus

    ```markdown
    # Rule: Real-World Deployment
    Description: Build production-ready applications
    Priority: High
    Requirements:
    - Comprehensive dependency management
    - Clear installation instructions
    - Proper logging and debugging
    - Cross-platform compatibility
    - Troubleshooting guides
    - Hardware-specific considerations
    - Multiple package manager support
    References:
    - See docs/development/workflow/deployment_workflow.md
    - See docs/framework/best_practices/deployment_guide.md
    ```

    ### 10. Value Delivery

    ```markdown
    # Rule: Incremental Value Delivery
    Description: Deliver value with each commit
    Priority: High
    Requirements:
    - Start simple and build incrementally
    - After initial generation, make small, focused changes (15 min - 2 hours)
    - Ensure working functionality
    - Prefer complete features
    - Test early and often with TDD
    - Update documentation at every cycle
    - Get user feedback on each increment
    References:
    - See docs/development/workflow/development_workflow.md
    - See docs/framework/methodology/AGILE_SPECFIRST.md
    ```

    ### 11. Error Handling

    ```markdown
    # Rule: Comprehensive Error Handling
    Description: Handle all error conditions
    Priority: High
    Requirements:
    - Validate API boundaries
    - Provide specific error messages
    - Log for debugging
    - Show user-friendly messages
    - Include recovery suggestions
    - Test error paths with TDD
    References:
    - See docs/development/testing/integration_testing.md
    - See docs/framework/patterns/error_handling.md
    ```

    ### 12. Component Design

    ```markdown
    # Rule: Single Responsibility
    Description: Clear component purposes
    Priority: High
    Requirements:
    - Functions do one thing
    - Classes represent single concepts
    - Files group related functionality
    - APIs have clear interfaces
    - Test each component with TDD
    References:
    - See docs/framework/patterns/README.md
    - See docs/development/testing/unit_testing.md
    ```

    ### 13. Development Practices

    ```markdown
    # Rule: Modern Development
    Description: Use current best practices
    Priority: High
    Requirements:
    - Modern API patterns
    - Responsive web design
    - Semantic HTML
    - Accessible design
    - RESTful APIs
    - TDD for quality assurance
    References:
    - See docs/framework/best_practices/README.md
    - See docs/development/workflow/development_workflow.md
    ```

    ### 14. Testing Strategy

    ```markdown
    # Rule: Testing and Validation
    Description: Comprehensive testing approach
    Priority: High
    Requirements:
    - Test success and failure with TDD
    - Validate against specifications
    - Integration testing
    - End-to-end testing
    - Environment verification
    - Hardware compatibility
    References:
    - See docs/development/testing/README.md
    - See docs/framework/patterns/testing_patterns.md
    ```

    ### 15. Environment Management

    ```markdown
    # Rule: Environment and Dependencies
    Description: Handle complex environments
    Priority: High
    Requirements:
    - Multiple installation paths
    - Environment verification
    - Package manager documentation
    - Hardware-specific setup
    - Debugging commands
    - Build verification
    - Quick-fix solutions
    References:
    - See docs/development/setup/environment_setup.md
    - See docs/framework/best_practices/deployment_guide.md
    ```

    ### 16. Knowledge Management

    ```markdown
    # Rule: Knowledge Preservation
    Description: Document decisions and learnings
    Priority: High
    Requirements:
    - Maintain conversation summaries
    - Document architecture decisions
    - Create implementation guides
    - Preserve context
    - Document PERA cycle learnings
    References:
    - See docs/development/documentation/README.md
    - See docs/framework/best_practices/README.md
    ```

    ### 17. Specification Maintenance

    ```markdown
    # Rule: Specification Maintenance
    Description: Keep specs in sync
    Priority: High
    Requirements:
    - Review after changes
    - Document changes
    - Maintain changelog
    - Validate implementation
    - Update based on feedback
    - Use PERA cycles for refinement
    References:
    - See docs/framework/methodology/AGILE_SPECFIRST.md
    - See docs/development/workflow/development_workflow.md
    ```

    ### 18. Documentation Sync

    ```markdown
    # Rule: Documentation Synchronization
    Description: Keep docs in sync
    Priority: High
    Requirements:
    - Update README.md
    - Maintain consistency
    - Document breaking changes
    - Keep API docs current
    - Update troubleshooting
    References:
    - See docs/development/documentation/README.md
    - See docs/framework/best_practices/documentation_guide.md
    ```

    ### 19. Version Control

    ```markdown
    # Rule: Version Control Integration
    Description: Integrate with version control
    Priority: High
    Requirements:
    - Clear commit messages
    - Version tagging
    - Specification history
    - Breaking change docs
    - Change tracking
    References:
    - See docs/development/workflow/development_workflow.md
    - See docs/framework/best_practices/version_control.md
    ```

    ### 20. Implementation Alignment

    ```markdown
    # Rule: Implementation-Specification Alignment
    Description: Ensure implementation matches specs
    Priority: Critical
    Requirements:
    - Validate before commits
    - Document deviations
    - Update specs when needed
    - Maintain traceability
    - Regular audits
    - Use TDD for validation
    References:
    - See docs/framework/best_practices/implementation_guide.md
    - See docs/development/testing/integration_testing.md
    ```

    ### 21. Documentation Structure

    ```markdown
    # Rule: Documentation Hierarchy
    Description: Maintain doc relationships
    Priority: High
    Requirements:
    - SPECIFICATIONS.md as source
    - README.md generation
    - docs/ structure
    - Update triggers
    - Consistent formatting
    - Version control
    References:
    - See docs/development/documentation/README.md
    - See docs/framework/best_practices/documentation_guide.md
    ```

    ### 22. Change Management

    ```markdown
    # Rule: Change Management
    Description: Handle framework changes
    Priority: High
    Requirements:
    - Document in .cursorrules
    - Update framework docs
    - Version control rules
    - Update process
    - Breaking change guidelines
    - Migration paths
    - Regular reviews
    References:
    - See docs/development/workflow/development_workflow.md
    - See docs/framework/best_practices/change_management.md
    ```

    ### 23. Quality Assurance

    ```markdown
    # Rule: Quality Assurance
    Description: Ensure quality standards
    Priority: High
    Requirements:
    - Automated checks
    - Validation rules
    - Documentation reviews
    - User feedback
    - Performance metrics
    - Revision criteria
    - TDD for quality assurance
    References:
    - See docs/development/testing/README.md
    - See docs/framework/best_practices/quality_standards.md
    ```

    ### 24. Cross-Project Standards

    ```markdown
    # Rule: Cross-Project Consistency
    Description: Maintain consistency
    Priority: High
    Requirements:
    - Shared templates
    - Common standards
    - Lessons learned
    - Framework updates
    - Versioning strategy
    - Best practices
    References:
    - See docs/framework/best_practices/README.md
    - See docs/development/workflow/development_workflow.md
    ```

    ### 25. Tool Integration

    ```markdown
    # Rule: Tool Integration
    Description: Integrate maintenance tools
    Priority: Medium
    Requirements:
    - Version control hooks
    - Documentation generation
    - Specification validation
    - Sync tools
    - Change tracking
    - Quality automation
    References:
    - See docs/development/setup/tool_setup.md
    - See docs/framework/best_practices/tool_integration.md
    ```

    ### 26. Decision Making

    ```markdown
    # Rule: Documentation-Driven Decisions
    Description: Guide decisions with docs
    Priority: High
    Requirements:
    - Follow specification guide
    - Use best practices
    - Check user preferences
    - Follow style guide
    - Update documentation
    References:
    - See docs/framework/methodology/AGILE_SPECFIRST.md
    - See docs/user/preferences/README.md
    ```

    ### 27. Test-Driven Development

    ```markdown
    # Rule: Test-First Development
    Description: Write tests before implementation
    Priority: High
    Requirements:
    - Write failing test before new feature
    - Test both success and failure cases
    - Validate against specifications
    - Run tests after each change
    - Use tests to guide implementation
    - Follow Red-Green-Refactor cycle
    - Test edge cases and error conditions
    References:
    - See docs/development/testing/unit_testing.md
    - See docs/framework/methodology/AGILE_SPECFIRST.md
    ```

    ### 28. Incremental Changes

    ```markdown
    # Rule: Small, Focused Changes
    Description: Make one small change at a time
    Priority: High
    Requirements:
    - Change one thing at a time
    - Test each change before proceeding with TDD
    - Validate against specifications
    - Get user feedback on each increment
    - Document what was changed and why
    - Break large changes into phases
    - Each phase must be testable independently
    References:
    - See docs/development/workflow/development_workflow.md
    - See docs/framework/methodology/AGILE_SPECFIRST.md
    ```

    ### 29. Change Validation

    ```markdown
    # Rule: Validate Before Committing
    Description: Ensure changes meet specifications
    Priority: Critical
    Requirements:
    - Run validation scripts after changes
    - Test both positive and negative cases with TDD
    - Verify no regressions introduced
    - Check that changes align with methodology
    - Get explicit approval for major changes
    - Use validation checklist before committing
    - Document any exceptions or deviations
    References:
    - See scripts/validate_project.py
    - See scripts/check_docs.py
    - See docs/framework/best_practices/implementation_guide.md
    ```

    ### 30. User Feedback Integration

    ```markdown
    # Rule: Rapid Feedback Loops
    Description: Get feedback early and often
    Priority: High
    Requirements:
    - Seek feedback at every stage
    - Use feedback to refine specifications
    - Incorporate feedback before closing features
    - Shorten feedback loops to catch issues early
    - Test with real users when possible
    - Document feedback and decisions
    References:
    - See docs/framework/methodology/AGILE_SPECFIRST.md
    - See docs/development/workflow/development_workflow.md
    ```

    ### 31. Specification Alignment

    ```markdown
    # Rule: Implementation-Specification Sync
    Description: Keep implementation aligned with specifications
    Priority: Critical
    Requirements:
    - Validate implementation against SPECIFICATIONS.md
    - Update specifications when implementation deviates
    - Maintain traceability between specs and code
    - Document any deviations with rationale
    - Regular audits of specification compliance
    - Use TDD for validation
    References:
    - See docs/framework/best_practices/implementation_guide.md
    - See docs/development/testing/integration_testing.md
    ```

    ### 32. Error Prevention

    ```markdown
    # Rule: Prevent Common Mistakes
    Description: Avoid common development pitfalls
    Priority: High
    Requirements:
    - Don't make multiple changes at once
    - Don't skip testing phases
    - Don't ignore user feedback
    - Don't proceed without validation
    - Don't violate incremental development principles
    - Document lessons learned from mistakes
    - Use TDD to prevent bugs
    References:
    - See docs/development/workflow/development_workflow.md
    - See docs/development/testing/unit_testing.md
    ```

    ### 33. PERA Cycle Management

    ```markdown
    # Rule: PERA Cycle Implementation
    Description: Implement PERA cycles for continuous improvement
    Priority: High
    Requirements:
    - Plan: Define specifications and requirements
    - Execute: Generate code and implement features with TDD
    - Report/Review: Validate with TDD and user feedback
    - Adjust: Refine specifications and implementation based on feedback
    - Complete full cycles regularly
    - Document learnings from each phase
    - Track cycle performance metrics
    References:
    - See docs/framework/methodology/AGILE_SPECFIRST.md
    - See docs/development/workflow/development_workflow.md
    ```

    ### 34. TDD Quality Assurance

    ```markdown
    # Rule: TDD as Quality Assurance
    Description: Use TDD for quality assurance throughout development
    Priority: High
    Requirements:
    - Write failing tests before implementation
    - Make tests pass with minimal code
    - Refactor while maintaining test coverage
    - Use tests to validate specification compliance
    - Maintain high test coverage (90%+)
    - Test both success and failure cases
    - Use tests as living documentation
    References:
    - See docs/development/testing/unit_testing.md
    - See docs/development/workflow/testing_workflow.md
    ```

    ## User Preferences

    ### Development Philosophy
    - Specification-First mindset
    - Technology-agnostic thinking
    - Real-World focus
    - Framework over features
    - Security-conscious
    - Documentation-heavy
    - TDD for quality assurance
    - PERA cycles for continuous improvement

    ### Technical Stack
    - Python with mamba/conda
    - AI API integration
    - Flask for web
    - Comprehensive testing with TDD
    - User-friendly errors
    - Multiple package managers

    ### Code Style
    - Copyright headers
    - Type hints
    - Google-style docstrings
    - PEP 8 compliance
    - Logical structure
    - Clear comments
    - TDD practices

    ### Project Structure
    - Version strategy
    - JSON configuration
    - Documentation hierarchy
    - Testing approach with TDD
    - Cross-platform support
    - PERA cycle integration

    ### AI Assistant Interaction
    - Clarification over assumption
    - Complete solutions
    - Specification validation
    - Proper tool usage
    - Context preservation
    - Learning integration
    - TDD guidance
    - PERA cycle facilitation

    ### Communication Style
    - Technical precision
    - Problem-solution format
    - Visual feedback
    - Progress tracking
    - Educational value

    ### Environment-Specific
    - WSL2/Ubuntu awareness
    - NVIDIA GPU support
    - Package management
    - VS Code integration
    - Local development

    ### Quality Assurance
    - Primary test cases with TDD
    - Edge case handling
    - User workflow testing
    - Documentation testing
    - Cross-platform testing
    - PERA cycle validation

    ### Decision-Making
    - Simplicity first
    - Future-proofing
    - User-centric
    - Evidence-based
    - Incremental progress
    - TDD-driven quality
    - PERA cycle improvement

    ## Framework Configuration

    This is a framework-level configuration file that defines how the AI assistant should behave when working with any project using the SpecFirst methodology. It is not meant to be generated per project, but rather serves as a single source of truth for AI behavior across all SpecFirst projects.

    ## Validation

    - [ ] All rules present
    - [ ] User preferences complete
    - [ ] Framework configuration clear
    - [ ] Timestamps updated
    - [ ] Version number set
    - [ ] No direct edits
    - [ ] Markdown valid
    - [ ] Links working
    - [ ] Format consistent
    - [ ] TDD integration complete
    - [ ] PERA cycle integration complete 

```