# User Preferences

## Overview
This section provides comprehensive guidance on user preferences and customization options within the SpecFirst framework. It covers development philosophy, technical stack preferences, communication styles, and environment-specific settings.

## Purpose
User preferences help customize the SpecFirst framework to individual needs and team requirements. These preferences guide AI assistant behavior, development processes, and project configuration.

## Development Philosophy

### Specification-First Mindset
- **Complete Specifications**: Always start with complete specifications before implementation
- **Documentation-Driven**: Use documentation as the primary driver for development
- **User-Centric Design**: Focus on user needs and workflows
- **Iterative Refinement**: Continuously refine specifications based on feedback

### Technology-Agnostic Thinking
- **Language Independence**: Focus on requirements rather than specific technologies
- **Cross-Platform Compatibility**: Design for multiple platforms and environments
- **Future-Proofing**: Choose technologies that can evolve with requirements
- **Portable Solutions**: Create solutions that can be adapted to different contexts

### Real-World Focus
- **Practical Implementation**: Focus on working, deployable solutions
- **User Experience**: Prioritize user experience and usability
- **Performance**: Consider real-world performance requirements
- **Maintainability**: Design for long-term maintenance and support

### Framework Over Features
- **Reusable Patterns**: Create reusable patterns and components
- **Scalable Architecture**: Design for scalability and growth
- **Consistent Standards**: Maintain consistent standards across projects
- **Best Practices**: Follow established best practices and patterns

## Technical Stack Preferences

### Python with Mamba/Conda
- **Environment Management**: Use mamba/conda for environment management
- **Package Management**: Prefer conda packages when available
- **Development Environment**: Use Python for backend development
- **Data Science**: Leverage Python's data science ecosystem

### AI API Integration
- **AI-First Development**: Integrate AI capabilities into applications
- **API Design**: Design APIs for AI integration
- **Error Handling**: Implement robust error handling for AI APIs
- **Performance**: Optimize for AI API performance

### Flask for Web
- **Lightweight Framework**: Use Flask for lightweight web applications
- **RESTful APIs**: Design RESTful APIs with Flask
- **Modular Design**: Create modular Flask applications
- **Testing**: Implement comprehensive testing for Flask apps

### Comprehensive Testing
- **Test-Driven Development**: Use TDD for quality assurance
- **Automated Testing**: Implement comprehensive automated testing
- **Coverage**: Maintain high test coverage
- **Performance Testing**: Include performance testing

### User-Friendly Errors
- **Clear Error Messages**: Provide clear, actionable error messages
- **User Guidance**: Guide users to solutions when errors occur
- **Logging**: Implement comprehensive logging for debugging
- **Recovery**: Provide recovery options for common errors

### Multiple Package Managers
- **Flexibility**: Support multiple package managers
- **Environment Compatibility**: Ensure compatibility across environments
- **Documentation**: Document package manager options
- **Fallback Options**: Provide fallback options for different environments

## Code Style

### Copyright Headers
- **Consistent Format**: Use consistent copyright header format
- **Author Information**: Include author and contact information
- **License Information**: Include appropriate license information
- **Version Information**: Include version and date information

### Type Hints
- **Comprehensive Hints**: Use type hints for all functions and methods
- **Documentation**: Use type hints as documentation
- **IDE Support**: Leverage IDE support for type hints
- **Validation**: Use type checking tools

### Google-Style Docstrings
- **Consistent Format**: Use Google-style docstring format
- **Complete Documentation**: Document all parameters and return values
- **Examples**: Include usage examples in docstrings
- **Maintenance**: Keep docstrings current with code changes

### PEP 8 Compliance
- **Style Consistency**: Follow PEP 8 style guidelines
- **Readability**: Prioritize code readability
- **Tooling**: Use automated tools for style enforcement
- **Team Standards**: Maintain consistent team standards

### Logical Structure
- **Clear Organization**: Organize code in logical, clear structure
- **Separation of Concerns**: Separate different concerns into modules
- **Dependency Management**: Manage dependencies clearly
- **File Organization**: Organize files logically

### Clear Comments
- **Purpose**: Comment on why, not what
- **Complex Logic**: Comment on complex logic and algorithms
- **Assumptions**: Document assumptions and constraints
- **Maintenance**: Keep comments current with code changes

## Project Structure

### Version Strategy
- **Semantic Versioning**: Use semantic versioning for releases
- **Change Tracking**: Track all changes and their impact
- **Release Notes**: Maintain comprehensive release notes
- **Backward Compatibility**: Maintain backward compatibility when possible

### JSON Configuration
- **Configuration Files**: Use JSON for configuration files
- **Environment Variables**: Use environment variables for sensitive data
- **Validation**: Validate configuration data
- **Documentation**: Document all configuration options

### Documentation Hierarchy
- **Clear Structure**: Maintain clear documentation hierarchy
- **Cross-References**: Use cross-references between documents
- **Version Control**: Version control all documentation
- **Accessibility**: Make documentation accessible to all users

### Testing Approach
- **Comprehensive Testing**: Implement comprehensive testing strategy
- **Automated Testing**: Automate testing processes
- **Continuous Integration**: Use CI/CD for testing
- **Quality Gates**: Use testing as quality gates

### Cross-Platform Support
- **Platform Independence**: Design for platform independence
- **Environment Compatibility**: Ensure compatibility across environments
- **Documentation**: Document platform-specific requirements
- **Testing**: Test across multiple platforms

## AI Assistant Interaction

### Clarification Over Assumption
- **Ask Questions**: Ask clarifying questions rather than making assumptions
- **Validate Understanding**: Validate understanding before proceeding
- **User Input**: Seek user input for important decisions
- **Documentation**: Document decisions and rationale

### Complete Solutions
- **End-to-End**: Provide complete, end-to-end solutions
- **Context**: Provide context and explanation
- **Examples**: Include practical examples
- **Documentation**: Document solutions thoroughly

### Specification Validation
- **Validate Specs**: Validate specifications before implementation
- **Completeness**: Ensure specification completeness
- **Clarity**: Ensure specification clarity
- **Feasibility**: Validate specification feasibility

### Proper Tool Usage
- **Appropriate Tools**: Use appropriate tools for each task
- **Efficiency**: Use tools efficiently
- **Documentation**: Document tool usage
- **Learning**: Learn from tool usage

### Context Preservation
- **Maintain Context**: Maintain context throughout interactions
- **History**: Reference previous interactions
- **Consistency**: Maintain consistency across interactions
- **Documentation**: Document context and decisions

### Learning Integration
- **Continuous Learning**: Integrate learning into development process
- **Feedback**: Use feedback for learning and improvement
- **Documentation**: Document learnings and insights
- **Sharing**: Share learnings with team

## Communication Style

### Technical Precision
- **Accurate Information**: Provide accurate, precise information
- **Clear Language**: Use clear, technical language
- **Documentation**: Document technical decisions
- **Validation**: Validate technical information

### Problem-Solution Format
- **Problem Statement**: Clearly state the problem
- **Solution Approach**: Explain the solution approach
- **Implementation**: Provide implementation details
- **Validation**: Validate the solution

### Visual Feedback
- **Progress Indicators**: Provide visual progress indicators
- **Status Updates**: Provide clear status updates
- **Error Visualization**: Visualize errors and solutions
- **Success Indicators**: Provide clear success indicators

### Progress Tracking
- **Milestones**: Track progress against milestones
- **Metrics**: Use metrics to track progress
- **Documentation**: Document progress and achievements
- **Communication**: Communicate progress regularly

### Educational Value
- **Learning Opportunities**: Identify learning opportunities
- **Explanation**: Explain concepts and decisions
- **Examples**: Provide educational examples
- **Documentation**: Document educational content

## Environment-Specific

### WSL2/Ubuntu Awareness
- **Environment Compatibility**: Ensure compatibility with WSL2/Ubuntu
- **Path Handling**: Handle path differences appropriately
- **Tool Compatibility**: Ensure tool compatibility
- **Documentation**: Document environment-specific requirements

### NVIDIA GPU Support
- **GPU Utilization**: Utilize NVIDIA GPUs when available
- **Performance Optimization**: Optimize for GPU performance
- **Fallback Options**: Provide CPU fallback options
- **Documentation**: Document GPU requirements and setup

### Package Management
- **Multiple Managers**: Support multiple package managers
- **Environment Isolation**: Use environment isolation
- **Dependency Management**: Manage dependencies effectively
- **Documentation**: Document package management options

### VS Code Integration
- **IDE Features**: Leverage VS Code features
- **Extensions**: Use appropriate VS Code extensions
- **Configuration**: Configure VS Code for optimal development
- **Documentation**: Document VS Code setup and configuration

### Local Development
- **Local Environment**: Optimize for local development
- **Quick Setup**: Provide quick setup instructions
- **Development Tools**: Use appropriate development tools
- **Documentation**: Document local development setup

## Quality Assurance

### Primary Test Cases
- **Core Functionality**: Test core functionality thoroughly
- **User Workflows**: Test complete user workflows
- **Edge Cases**: Test edge cases and boundary conditions
- **Error Conditions**: Test error conditions and handling

### Edge Case Handling
- **Boundary Testing**: Test boundary conditions
- **Error Scenarios**: Test error scenarios
- **Performance Limits**: Test performance limits
- **Security Edge Cases**: Test security edge cases

### User Workflow Testing
- **End-to-End Testing**: Test complete user workflows
- **User Experience**: Test user experience aspects
- **Performance**: Test workflow performance
- **Accessibility**: Test workflow accessibility

### Documentation Testing
- **Accuracy**: Test documentation accuracy
- **Completeness**: Test documentation completeness
- **Clarity**: Test documentation clarity
- **Accessibility**: Test documentation accessibility

### Cross-Platform Testing
- **Platform Compatibility**: Test across multiple platforms
- **Environment Compatibility**: Test across different environments
- **Tool Compatibility**: Test tool compatibility
- **Performance**: Test performance across platforms

## Decision-Making

### Simplicity First
- **Simple Solutions**: Prefer simple solutions over complex ones
- **Clear Understanding**: Ensure clear understanding of solutions
- **Maintainability**: Prioritize maintainability
- **Documentation**: Document simple solutions clearly

### Future-Proofing
- **Scalability**: Design for scalability
- **Flexibility**: Design for flexibility
- **Extensibility**: Design for extensibility
- **Documentation**: Document future-proofing decisions

### User-Centric
- **User Needs**: Focus on user needs
- **User Experience**: Prioritize user experience
- **User Feedback**: Incorporate user feedback
- **Documentation**: Document user-centric decisions

### Evidence-Based
- **Data-Driven**: Use data to inform decisions
- **Testing**: Test decisions and assumptions
- **Validation**: Validate decisions
- **Documentation**: Document evidence and rationale

### Incremental Progress
- **Small Steps**: Make small, incremental progress
- **Continuous Improvement**: Focus on continuous improvement
- **Learning**: Learn from each step
- **Documentation**: Document progress and learnings

## References
- [AGILE_SPECFIRST.md](../framework/methodology/AGILE_SPECFIRST.md) - Core methodology
- [VIBE_USER_GUIDE.md](../framework/methodology/VIBE_USER_GUIDE.md) - User guidance
- [CURSOR_INTEGRATION.md](../framework/methodology/CURSOR_INTEGRATION.md) - IDE integration
- [EXAMPLE_SPECIFICATIONS.md](../framework/methodology/EXAMPLE_SPECIFICATIONS.md) - Examples 