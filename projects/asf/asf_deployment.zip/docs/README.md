# Documentation Overview

This directory contains the complete documentation for the Agile SpecFirst (ASF) Development Framework. The documentation is organized into logical domains to help you find the information you need quickly and efficiently.

## Directory Organization

### Framework Documentation (`framework/`)
Core methodology, patterns, and best practices that apply to all projects using the SpecFirst approach.

- **methodology/** - Core methodology documentation
  - [AGILE_SPECFIRST.md](framework/methodology/AGILE_SPECFIRST.md) - Core methodology with TDD and PERA integration
  - [VIBE_USER_GUIDE.md](framework/methodology/VIBE_USER_GUIDE.md) - Beginner-friendly guide
  - [CURSOR_INTEGRATION.md](framework/methodology/CURSOR_INTEGRATION.md) - Cursor IDE integration details
  - [EXAMPLE_SPECIFICATIONS.md](framework/methodology/EXAMPLE_SPECIFICATIONS.md) - Example project specifications
  - [SPECIFICATION_VALIDATION.md](framework/methodology/SPECIFICATION_VALIDATION.md) - Specification validation and QA/QC guide
  - [CURSOR_RULES.md](framework/methodology/CURSOR_RULES.md) - Guide for `.cursorrules` file structure
  - [SCRIPTS_SPECS.md](framework/methodology/SCRIPTS_SPECS.md) - Specifications for framework validation scripts

- **best_practices/** - Implementation guidelines and best practices
  - [README.md](framework/best_practices/README.md) - Overview of best practices

- **patterns/** - Reusable design patterns
  - [README.md](framework/patterns/README.md) - Overview of patterns

- **style/** - Code and documentation style guides
  - [README.md](framework/style/README.md) - Style guide overview

### Development Documentation (`development/`)
Project implementation, workflows, and technology-specific guidance.

- **workflow/** - Development process and workflows
  - [README.md](development/workflow/README.md) - Workflow overview
  - [development_workflow.md](development/workflow/development_workflow.md) - Core development workflow
  - [testing_workflow.md](development/workflow/testing_workflow.md) - Testing workflow
  - [deployment_workflow.md](development/workflow/deployment_workflow.md) - Deployment workflow

- **testing/** - Testing strategies and implementation
  - [README.md](development/testing/README.md) - Testing overview
  - [unit_testing.md](development/testing/unit_testing.md) - Unit testing guide
  - [integration_testing.md](development/testing/integration_testing.md) - Integration testing guide
  - [e2e_testing.md](development/testing/e2e_testing.md) - End-to-end testing guide

- **setup/** - Environment and project setup
  - [README.md](development/setup/README.md) - Setup overview

- **documentation/** - Documentation management
  - [README.md](development/documentation/README.md) - Documentation overview

### Default Configurations (`defaults/`)
Templates and default settings for quick project setup.

- **templates/** - Reusable templates
  - **copyright/** - Copyright templates
    - [README.md](defaults/templates/copyright/README.md) - Copyright overview
    - [documentation.md](defaults/templates/copyright/documentation.md) - Documentation copyright template
  - **framework/** - Framework-specific templates
    - [agile_integration.md](defaults/templates/framework/agile_integration.md) - Agile integration template
    - [deployment_guide.md](defaults/templates/framework/deployment_guide.md) - Deployment guide template
    - [expected_behavior.md](defaults/templates/framework/expected_behavior.md) - Expected behavior template
    - [implementation_guide.md](defaults/templates/framework/implementation_guide.md) - Implementation guide template
    - [specification_guide.md](defaults/templates/framework/specification_guide.md) - Specification guide template
    - [value_proposition.md](defaults/templates/framework/value_proposition.md) - Value proposition template
  - **security/** - Security templates
    - [security.md](defaults/templates/security/security.md) - Security template

- **settings/** - Default configuration settings
  - [README.md](defaults/settings/README.md) - Settings overview

### User Documentation (`user/`)
User-specific documentation, preferences, and customizations.

- **communication/** - Communication guidelines
  - [README.md](user/communication/README.md) - Communication overview

- **preferences/** - User preferences and settings
  - [README.md](user/preferences/README.md) - User preferences overview

- **config/** - User-generated configuration (empty by default)
- **custom/** - User-generated customizations (empty by default)

## Quick Reference

### Getting Started
1. **New to SpecFirst?** Start with [VIBE_USER_GUIDE.md](framework/methodology/VIBE_USER_GUIDE.md)
2. **Understanding the methodology?** Read [AGILE_SPECFIRST.md](framework/methodology/AGILE_SPECFIRST.md)
3. **Setting up a project?** Check [development_workflow.md](development/workflow/development_workflow.md)
4. **Need examples?** Review [EXAMPLE_SPECIFICATIONS.md](framework/methodology/EXAMPLE_SPECIFICATIONS.md)

### Development Workflow
1. **Specification Creation** - Define requirements in SPECIFICATIONS.md
2. **Documentation Generation** - Generate docs from specifications
3. **Implementation** - Code generation and development
4. **Testing** - Validate against specifications
5. **Validation** - Run project validation scripts
6. **Deployment** - Package and deploy

### Key Files
- **SPECIFICATIONS.md** - Project root, contains complete project definition
- **.cursorrules** - AI assistant implementation guide (generated)
- **README.md** - Project interface (generated)
- **scripts/validate_project.py** - Project validation tool
- **scripts/check_docs.py** - Documentation validation tool

### Validation Commands
```bash
# Check overall project status
python scripts/validate_project.py

# Check documentation completeness
python scripts/check_docs.py

# Create deployment package
python scripts/deploy_package.py --root-dir .
```

## Documentation Standards

- **Source of Truth**: SPECIFICATIONS.md is the primary source of truth
- **Generated Content**: README.md and .cursorrules are generated from specifications
- **Cross-References**: All documentation files maintain consistent cross-references
- **Version Control**: Documentation is versioned with the project
- **Quality**: All documentation follows established standards and patterns

## Support and Feedback

For questions, issues, or feedback about the documentation:
1. Check the troubleshooting sections in relevant guides
2. Review the validation scripts for specific requirements
3. Refer to the methodology documentation for process guidance
4. Use the example specifications as reference implementations

---

*This documentation is generated from SPECIFICATIONS.md and maintained as part of the Agile SpecFirst Development Framework.* 