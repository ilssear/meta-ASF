# Specification Guide Template

This file explains how to write, maintain, and validate specifications in the SpecFirst framework. Use this template to guide contributors in creating clear, actionable, and LLM-friendly specifications.

- Describe the structure and required sections of a specification.
- Provide tips for clarity, completeness, and traceability.
- Reference examples and best practices. 