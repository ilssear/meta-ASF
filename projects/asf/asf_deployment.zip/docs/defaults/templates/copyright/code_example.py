# Copyright (c) 2025, Jaime Moraga (jmoraga@mines.edu)
#
# This file is part of the [Project Name] project.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""
[Function/Class Name] - Example Implementation

This module demonstrates [specific functionality or pattern].

Example:
    >>> from [module_name] import [function_name]
    >>> result = [function_name]([parameters])
    >>> print(result)
    [expected_output]

Author: Jaime Moraga (jmoraga@mines.edu)
Version: [version]
Last Updated: [date]
"""

from typing import Any, Dict, List, Optional, Union


def example_function(param1: str, param2: int = 42) -> str:
    """
    Example function demonstrating proper documentation and type hints.
    
    This function shows how to:
    - Use type hints for parameters and return values
    - Write comprehensive docstrings
    - Handle different parameter types
    - Return appropriate values
    
    Args:
        param1: A string parameter with description
        param2: An optional integer parameter with default value
        
    Returns:
        A formatted string combining the parameters
        
    Raises:
        ValueError: If param1 is empty or param2 is negative
        
    Example:
        >>> example_function("hello", 123)
        'hello-123'
        >>> example_function("test")
        'test-42'
    """
    if not param1:
        raise ValueError("param1 cannot be empty")
    
    if param2 < 0:
        raise ValueError("param2 cannot be negative")
    
    return f"{param1}-{param2}"


class ExampleClass:
    """
    Example class demonstrating proper class documentation and structure.
    
    This class shows how to:
    - Document classes with comprehensive docstrings
    - Use type hints for class attributes
    - Implement proper initialization
    - Add property decorators
    - Include usage examples
    
    Attributes:
        name: The name of the instance
        value: The numeric value of the instance
        
    Example:
        >>> obj = ExampleClass("test", 42)
        >>> print(obj.name)
        'test'
        >>> print(obj.value)
        42
        >>> print(obj.formatted_value)
        'test: 42'
    """
    
    def __init__(self, name: str, value: int):
        """
        Initialize the ExampleClass instance.
        
        Args:
            name: The name for this instance
            value: The numeric value for this instance
        """
        self._name = name
        self._value = value
    
    @property
    def name(self) -> str:
        """Get the name of this instance."""
        return self._name
    
    @property
    def value(self) -> int:
        """Get the value of this instance."""
        return self._value
    
    @property
    def formatted_value(self) -> str:
        """Get a formatted string representation."""
        return f"{self._name}: {self._value}"
    
    def update_value(self, new_value: int) -> None:
        """
        Update the value of this instance.
        
        Args:
            new_value: The new value to set
            
        Raises:
            ValueError: If new_value is negative
        """
        if new_value < 0:
            raise ValueError("Value cannot be negative")
        self._value = new_value
    
    def __str__(self) -> str:
        """Return string representation of the instance."""
        return f"ExampleClass(name='{self._name}', value={self._value})"
    
    def __repr__(self) -> str:
        """Return detailed string representation of the instance."""
        return f"ExampleClass(name='{self._name}', value={self._value})"


def main() -> None:
    """
    Main function demonstrating usage of the example code.
    
    This function shows how to use the example_function and ExampleClass.
    """
    # Example usage of the function
    try:
        result = example_function("hello", 123)
        print(f"Function result: {result}")
    except ValueError as e:
        print(f"Function error: {e}")
    
    # Example usage of the class
    try:
        obj = ExampleClass("test", 42)
        print(f"Object: {obj}")
        print(f"Formatted value: {obj.formatted_value}")
        
        obj.update_value(100)
        print(f"Updated object: {obj}")
    except ValueError as e:
        print(f"Class error: {e}")


if __name__ == "__main__":
    main() 