# Copyright Templates for SpecFirst Framework

This directory contains copyright templates and guidelines for the SpecFirst framework. These templates ensure consistent copyright headers across all project files and maintain proper attribution.

## Purpose
The copyright templates provide standardized copyright headers for different file types and project contexts. They ensure legal compliance and proper attribution while maintaining consistency across the framework.

## Template Types

### 1. Code Files (.py, .js, .java, etc.)
```python
# Copyright (c) 2025, Jaime Moraga (jmoraga@mines.edu)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
```

### 2. Documentation Files (.md, .txt)
```markdown
# Copyright (c) 2025, Jaime Moraga (jmoraga@mines.edu)

This document is part of the SpecFirst framework and is licensed under the Apache License, Version 2.0.
```

### 3. Configuration Files (.json, .yaml, .yml)
```json
{
  "_copyright": "Copyright (c) 2025, Jaime Moraga (jmoraga@mines.edu)",
  "_license": "Apache License, Version 2.0",
  "_license_url": "http://www.apache.org/licenses/LICENSE-2.0"
}
```

## Usage Guidelines

### When to Use Copyright Headers
- All source code files
- All documentation files
- Configuration templates
- Script files
- Template files

### When Not to Use Copyright Headers
- Generated files
- Third-party dependencies
- Temporary files
- Build artifacts

### Copyright Information
- **Author**: Jaime Moraga (jmoraga@mines.edu)
- **Year**: 2025 (current year)
- **License**: Apache License, Version 2.0
- **License URL**: http://www.apache.org/licenses/LICENSE-2.0

## Implementation

### Automated Copyright Addition
The framework includes tools to automatically add copyright headers to new files:

```bash
# Add copyright to a new Python file
python scripts/add_copyright.py --file src/new_module.py --type python

# Add copyright to a new documentation file
python scripts/add_copyright.py --file docs/new_guide.md --type markdown
```

### Copyright Validation
The framework validates copyright headers during project validation:

```bash
# Check copyright compliance
python scripts/validate_project.py --check-copyright
```

## License Information

### Apache License 2.0
The SpecFirst framework is licensed under the Apache License, Version 2.0. This license:

- Allows commercial use
- Allows modification
- Allows distribution
- Allows patent use
- Provides liability protection
- Requires license and copyright notice

### Key Requirements
1. Include the original copyright notice
2. Include the Apache License text or reference
3. State significant changes made
4. Include NOTICE file if applicable

## Framework Integration

### Copyright Standards
The framework enforces consistent copyright standards:
- Standardized format across all file types
- Automated validation and addition
- Integration with project generation tools
- Compliance checking in CI/CD pipelines

### Template Management
- Templates are version-controlled
- Updates are applied across all projects
- Automated migration tools available
- Backward compatibility maintained

## Best Practices

### Copyright Headers
- Keep headers concise and clear
- Include all required license information
- Use consistent formatting
- Update year when making significant changes

### License Compliance
- Understand license requirements
- Include license text or references
- Maintain NOTICE files when required
- Document third-party dependencies

### Attribution
- Credit original authors
- Document modifications
- Maintain change history
- Respect third-party licenses

## Tools and Automation

### Copyright Management Tools
- `add_copyright.py`: Add headers to new files
- `validate_copyright.py`: Check compliance
- `update_copyright.py`: Update existing headers
- `copyright_report.py`: Generate compliance reports

### Integration Points
- Project generation templates
- File creation workflows
- Validation pipelines
- Documentation generation

## References
- [Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0)
- [Copyright Best Practices](../framework/best_practices/copyright_guide.md)
- [License Management](../development/workflow/license_management.md) 