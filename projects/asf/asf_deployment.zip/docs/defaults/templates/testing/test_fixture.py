# Copyright (c) 2025, Jaime Moraga (jmoraga@mines.edu)
"""
Test Fixture Template

This file provides a template for reusable test fixtures in SpecFirst-based projects. Use this as a starting point for setting up test data, mocks, and environment configuration for your test suite.

- Define common setup and teardown logic
- Provide sample data and mocks
- Reference testing best practices
"""

# Implementation goes here 